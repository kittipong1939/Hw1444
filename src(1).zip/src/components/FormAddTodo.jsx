
function FormAddTodo() {
  return (
    <form className="form-add-todo">
      <input type="text" />
      <button type="submit">Add</button>
    </form>
  )
}

export default FormAddTodo